<?php
include 'config.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $item = $_POST['item'];
    $pid = $_POST['pid'];
    $qty = $_POST['qty'];
    $address = $_POST['address'];

    $sql = "INSERT INTO orders (name, email, phone, item, pid, qty, address) VALUES ('$name', '$email', '$phone', '$item', '$pid', '$qty', '$address')";

    if ($conn->query($sql) === TRUE) {
        echo "<script type='text/javascript'>alert('Order placed successfully');</script>";
    } else {
        echo "<script type='text/javascript'>alert('Error: " . $conn->error . "');</script>";
    }

    $conn->close();
}
?>
